/*
  APP LAYOUT + PAGES
  Every page shares the Navbar and Footer. The <Routes> list decides which
  page shows for each web address.
*/
import { useEffect } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import Navbar from './Navbar.jsx'
import Footer from './Footer.jsx'
import Home from './Home.jsx'
import SessionPage from './SessionPage.jsx'
import ReflectionsPage from './ReflectionsPage.jsx'
import NotFound from './NotFound.jsx'

export default function App() {
  const { pathname, hash } = useLocation()

  // Scroll to the top whenever you switch page
  // (unless the link points to a section, like /#progress).
  useEffect(() => {
    if (!hash) window.scrollTo(0, 0)
  }, [pathname, hash])

  return (
    <div className="app">
      <Navbar />
      <main className="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/session/:sessionId" element={<SessionPage />} />
          <Route path="/reflections" element={<ReflectionsPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}
